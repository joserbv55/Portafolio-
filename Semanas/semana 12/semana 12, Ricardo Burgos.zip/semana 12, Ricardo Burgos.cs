﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace semana_12
{

    class Program
    {
        static void Main(string[] args)
        {
            double catetoA, anguloOpuestoA;

            Console.WriteLine("Ingrese la longitud del cateto A (en metros):");
            catetoA = double.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese la amplitud del ángulo opuesto al cateto A (en grados):");
            anguloOpuestoA = double.Parse(Console.ReadLine());

            TrianguloRectangulo objTriangulo = new TrianguloRectangulo(catetoA, anguloOpuestoA);

            Console.WriteLine("\nResultados:");
            Console.WriteLine("Valor de cateto a: " + objTriangulo.ObtenerCatetoA() + " metros");
            Console.WriteLine("Valor de cateto b: " + objTriangulo.ObtenerCatetoB() + " metros");
            Console.WriteLine("Valor de hipotenusa: " + objTriangulo.ObtenerHipotenusa() + " metros");
            Console.WriteLine("Valor de ángulo opuesto de A: " + objTriangulo.ObtenerAnguloOpuestoA() + " grados");
            Console.WriteLine("Valor de ángulo opuesto de B: " + objTriangulo.ObtenerAnguloOpuestoB() + " grados");
            Console.WriteLine("Valor de área: " + objTriangulo.ObtenerArea() + " metros cuadrados");
            Console.ReadKey();
        }
    }

           class TrianguloRectangulo
        {
            private double catetoA;
            private double anguloOpuestoA;

            public TrianguloRectangulo(double catetoA, double anguloOpuestoA)
            {
                this.catetoA = catetoA;
                this.anguloOpuestoA = anguloOpuestoA;
            }

            public double ObtenerCatetoA()
            {
                return catetoA;
            }

            public double ObtenerCatetoB()
            {
                double catetoB = catetoA * Math.Tan(Math.PI * anguloOpuestoA / 180);
                return Math.Round(catetoB, 3);
            }

            public double ObtenerHipotenusa()
            {
                double hipotenusa = catetoA / Math.Cos(Math.PI * anguloOpuestoA / 180);
                return Math.Round(hipotenusa, 3);
            }

            public double ObtenerAnguloOpuestoA()
            {
                return anguloOpuestoA;
            }

            public double ObtenerAnguloOpuestoB()
            {
                double anguloOpuestoB = 90 - anguloOpuestoA;
                return Math.Round(anguloOpuestoB, 3);
            }

            public double ObtenerArea()
            {
                double area = 0.5 * catetoA * ObtenerCatetoB();
                return Math.Round(area, 3);
            
            }

        }


}
