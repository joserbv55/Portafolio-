﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T9__JRBV_1087023
{
    internal class Program
    {
         

            public class Motocicleta
        {
            private int Modelo = 2019;
            private double Precio = 1000;
            private string Marca = "";
            private double Iva = 0.12;

            public string MostrarDatos()
            {
                return $"Modelo: {Modelo}, Precio: {Precio}, Marca: {Marca}, IVA: {Iva}";
            }

            public void DefinirPrecio(double precio)
            {
                this.Precio = precio;
            }

            public void DefinirIva(double iva)
            {
                if (iva >= 0.01 && iva <= 0.99)
                {
                    this.Iva = iva;
                }
                else
                {
                    throw new ArgumentException("El IVA debe estar entre 0.01 y 0.99");
                }
            }

            public double PrecioSinIva()
            {
                return this.Precio / (1 + this.Iva);
            }

            public double PrecioConIva()
            {
                return this.Precio;
            }

            public double DevolverIva()
            {
                return this.Precio - PrecioSinIva();
            }
        }
       
            static void Main(string[] args)
            {
                Motocicleta objMotocicleta = new Motocicleta();
                Console.WriteLine(objMotocicleta.MostrarDatos());
                Console.WriteLine($"Precio sin IVA de la motocicleta: {objMotocicleta.PrecioSinIva()}");
                Console.WriteLine($"Precio con IVA: {objMotocicleta.PrecioConIva()}");
                Console.WriteLine($"Sólo el monto del IVA: {objMotocicleta.DevolverIva()}");
                Console.ReadKey();
            }
        }

    }


